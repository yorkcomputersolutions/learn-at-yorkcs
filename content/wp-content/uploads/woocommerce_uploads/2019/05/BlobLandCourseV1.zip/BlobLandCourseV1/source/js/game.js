var config = {
  type: Phaser.AUTO,
  width: 480,
  height: 640,
  backgroundColor: "#17d8ff",
  physics: {
    default: "arcade",
    arcade: {
      gravity: { x: 0, y: 500 }
    }
  },
  scene: [SceneMain],
  pixelArt: true,
  roundPixels: true
};

var game = new Phaser.Game(config);

