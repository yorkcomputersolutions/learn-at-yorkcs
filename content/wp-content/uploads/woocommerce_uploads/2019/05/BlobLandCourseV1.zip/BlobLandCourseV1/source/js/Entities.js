class HighscoreManager {
  read() {
    var value = localStorage.getItem("highscore");

    // If the value is not null, retain the value, otherwise if value is null, set value to 0
    value = value !== null ? value : 0;
    
    return value;
  }

  saveIfNeeded(score) { // Checks if score entered is higher than the high score stored
    if (score > this.read()) {
      localStorage.setItem("highscore", score);
    }
  }
}

class MenuButton extends Phaser.GameObjects.Sprite {
  constructor(scene, x, y, callback) {
    super(scene, x, y, "sprBtnPlay");
    this.scene = scene;
    this.scene.add.existing(this);

    this.callback = callback;

    this.setScale(this.scene.spriteScale);
    this.setDepth(10);

    // setInteractive needs to be called before pointer events work
    this.setInteractive();

    // Our pointer events
    this.on("pointerover", function() {
      this.setScale(this.scene.spriteScale - 0.1);
    }, this);

    this.on("pointerout", function() {
      this.setScale(this.scene.spriteScale);
    }, this);

    this.on("pointerdown", function() {
      this.setScale(this.scene.spriteScale - 0.1);
      callback();
    }, this);
    
    this.on("pointerup", function() {
      this.setScale(this.scene.spriteScale);
      callback();
    }, this);
  }
}

class TextLongShadow extends Phaser.GameObjects.Text {
  constructor(scene, x, y, string, shadowSize, config) {
    super(scene, x, y, string, config);
    this.scene = scene;
    this.scene.add.existing(this);

    this.shadowSize = shadowSize;
    
    // Copy config to shadowConfig, then modify the color
    var shadowConfig = { };
    Object.assign(shadowConfig, config);
    shadowConfig.color = "#000000";

    // Create the shadows for our text
    this.textShadows = this.scene.add.group();
    for (var i = 0; i < this.shadowSize; i++) {
      var shadowText = this.scene.add.text(x + (i * 2), y + (i * 2), string, shadowConfig);
      shadowText.setDepth(this.depth - i);
      this.textShadows.add(shadowText);
    }
  }

  // Below are methods that allow this text to be displayed, while updating the shadow text objects too

  setVisibleWithLongShadow(isVisible) {
    this.setVisible(isVisible);

    for (var i = 0; i < this.textShadows.getChildren().length; i++) {
      this.textShadows.getChildren()[i].setVisible(isVisible);
    }
  }

  setTextWithLongShadow(string) {
    this.setText(string);

    for (var i = 0; i < this.textShadows.getChildren().length; i++) {
      this.textShadows.getChildren()[i].setText(string);
    }
  }

  setOriginWithLongShadow(originX, originY) {
    this.setOrigin(originX, originY);

    for (var i = 0; i < this.textShadows.getChildren().length; i++) {
      this.textShadows.getChildren()[i].setOrigin(originX, originY);
    }
  }

  setDepthWithLongShadow(depth) {
    this.setDepth(depth);

    for (var i = 0; i < this.textShadows.getChildren().length; i++) {
      this.textShadows.getChildren()[i].setDepth(depth - 10);
    }
  }
}

class Entity extends Phaser.GameObjects.Sprite {
  constructor(scene, x, y, key) {
    super(scene, x, y, key);
    this.scene = scene;
    this.scene.add.existing(this);
    this.scene.physics.world.enableBody(this, 0);
    this.setScale(scene.spriteScale);
  }
}

class Cloud extends Entity {
  constructor(scene, x, y, velocity, key) {
    super(scene, x, y, key);
    this.body.setAllowGravity(false);
    this.body.setImmovable(true);
    
    this.body.velocity = velocity;
    this.setScale(Math.pow(Math.abs(this.body.velocity.x), 2) * 0.0001);
    this.setDepth(-(5 + Math.floor(1 / this.scaleX)));
    this.setAlpha(Phaser.Math.Between(7, 10) * 0.1);
  }
}

class Pillar extends Entity {
  constructor(scene, x, y, key) {
    super(scene, x, y, key);
    this.body.setAllowGravity(false);
    this.body.setImmovable(true);
  }
}

class World {
  constructor(scene) {
    this.scene = scene;

    // Define groups in our game world
    this.clouds = this.scene.add.group();
    this.pillars = this.scene.add.group();
    this.pillarBlobs = this.scene.add.group();
    this.balloonBlobs = this.scene.add.group();
    this.beanieBlobs = this.scene.add.group();
    this.rocketBlobs = this.scene.add.group();
    this.bubbles = this.scene.add.group();
    this.itemDrops = this.scene.add.group();

    // An object to keep item templates organized
    this.itemTemplates = {
      JELLY: new ItemTemplate("sprParticlePlayer", function(world, player) {
        player.setScale(player.scaleX + 0.1);
      })
    };

    this.pillarScrollSpeed = 100;
    this.amountPillarsSpawned = 0;
    this.amountPillarsAttemptedSpawn = 0;
  }

  spawnItemDrop(x, y, itemTemplate) {
    var itemDrop = new ItemDrop(this.scene, x, y, itemTemplate);
    itemDrop.body.velocity.x = -this.pillarScrollSpeed + Phaser.Math.Between(-30, 30);
    this.itemDrops.add(itemDrop);
  }

  spawnCloud() {

    var cloudVelocity = new Phaser.Math.Vector2(
      -Phaser.Math.Between(20, 200),
      0
    );

    var cloud = new Cloud(
      this.scene,
      this.scene.game.config.width + 512,
      Phaser.Math.Between(0, this.scene.game.config.height),
      cloudVelocity,
      "sprCloudLarge" + Phaser.Math.Between(0, 1)
    );
    this.clouds.add(cloud);

  }

  spawnPillar() {
    var canSpawn = false;

    if (this.amountPillarsSpawned < 10) {
      canSpawn = true;
    }
    else {
      if (this.amountPillarsAttemptedSpawn % 5 == 0) {
        canSpawn = true;
      }
    }


    if (canSpawn) {
      var types = [
        "TOP",
        "BOTTOM",
        "BOTH"
      ];

      // Pick a specific layout type for spawning the pillar
      var type = types[Phaser.Math.Between(0, types.length - 1)];

      switch (type) {
        case "TOP": {
          var pillar = new Pillar(this.scene, this.scene.game.config.width + 128, Phaser.Math.Between(-128, 128), "sprPillarDown");
          pillar.body.velocity.x = -this.pillarScrollSpeed;
          this.pillars.add(pillar);

          break;
        }

        case "BOTTOM": {
          var pillar = new Pillar(this.scene, this.scene.game.config.width + 128, this.scene.game.config.height + Phaser.Math.Between(-128, 128), "sprPillarUp");
          pillar.body.velocity.x = -this.pillarScrollSpeed;
          this.pillars.add(pillar);

          var pillarBlob = new PillarBlob(this.scene, pillar.x, pillar.y - (pillar.displayHeight * 0.5), pillar);
          pillarBlob.y += pillarBlob.displayHeight * 0.25;
          pillarBlob.y -= pillarBlob.displayHeight * 0.35;
          this.pillarBlobs.add(pillarBlob);

          break;
        }

        case "BOTH": {
          var pillarTop = new Pillar(this.scene, this.scene.game.config.width + 128, Phaser.Math.Between(-128, 128), "sprPillarDown");
          pillarTop.body.velocity.x = -this.pillarScrollSpeed;
          this.pillars.add(pillarTop);

          var pillarBottom = new Pillar(this.scene, this.scene.game.config.width + 128, pillarTop.y + (pillarTop.displayHeight + 128), "sprPillarUp");
          pillarBottom.body.velocity.x = -this.pillarScrollSpeed;
          this.pillars.add(pillarBottom);

          break;
        }  
      }

      if (this.amountPillarsSpawned > 0) {
        if (!this.scene.player.getData("isDead")) {
          this.scene.addToScore(1);
        }
      }

      this.amountPillarsSpawned++;
    }

    this.amountPillarsAttemptedSpawn++;
  }

  spawnBubble() {
    var bubble = new Bubble(
      this.scene,
      this.scene.game.config.height + 128,
      Phaser.Math.Between(0, this.scene.game.config.height),
      this.itemTemplates.JELLY
    );
    bubble.body.velocity.x = -this.pillarScrollSpeed;
    this.bubbles.add(bubble);
  }

  spawnBeanieBlob() {

    if (this.amountPillarsSpawned > 10) {
      var blob = new BeanieBlob(
        this.scene,
        this.scene.game.config.width,
        Phaser.Math.Between(0, this.scene.game.config.height)
      );

      blob.body.velocity.x = -100;

      this.beanieBlobs.add(blob);  
    }
  }

  spawnRocketBlob() {

    if (this.amountPillarsSpawned > 5) {

      var blob = new RocketBlob(
        this.scene,
        this.scene.game.config.width + 128,
        Phaser.Math.Between(0, this.scene.game.config.height)
      );

      this.rocketBlobs.add(blob);

      this.spawnRocketBlobEvent.delay = Phaser.Math.Between(10000, 50000);
    }
  }

  startSpawnTimers() {
    this.spawnPillarEvent = this.scene.time.addEvent({
      delay: 3000,
      callback: this.spawnPillar,
      callbackScope: this,
      loop: true
    });

    this.spawnBubbleEvent = this.scene.time.addEvent({
      delay: 5000,
      callback: this.spawnBubble,
      callbackScope: this,
      loop: true
    });

    this.spawnBalloonBlobEvent = this.scene.time.addEvent({
      delay: 3000,
      callback: function() {
        var balloon = new BalloonBlob(
          this.scene,
          this.scene.game.config.width + 128,
          this.scene.game.config.height
        );
        balloon.body.velocity.x = -this.pillarScrollSpeed;
        balloon.body.velocity.y = -Phaser.Math.Between(50, 200);
        this.balloonBlobs.add(balloon);
  
        this.spawnerBalloonBlobTick = 0;
      },
      callbackScope: this,
      loop: true
    });

    this.spawnBeanieEvent = this.scene.time.addEvent({
      delay: 3000,
      callback: this.spawnBeanieBlob,
      callbackScope: this,
      loop: true
    });

    this.spawnRocketBlobEvent = this.scene.time.addEvent({
      delay: 10000,
      callback: this.spawnRocketBlob,
      callbackScope: this,
      loop: true
    });

    this.scene.time.addEvent({
      delay: 1000,
      callback: function() {
        this.spawnCloud();
      },
      callbackScope: this,
      loop: true
    });
  }

  update() {

    // Cull game objects that go out of view
    for (var i = 0; i < this.clouds.getChildren().length; i++) {
      var cloud = this.clouds.getChildren()[i];

      if (cloud.x < -256) {
        cloud.destroy();
      }
    }
    
    for (var i = 0; i < this.pillars.getChildren().length; i++) {
      var pillar = this.pillars.getChildren()[i];

      if (pillar.x < -64) {
        pillar.destroy();
      }
    }

    for (var i = 0; i < this.pillarBlobs.getChildren().length; i++) {
      var pillarBlob = this.pillarBlobs.getChildren()[i];

      pillarBlob.update();

      if (pillarBlob.x < -64) {
        pillarBlob.destroy();
        pillarBlob.eyes.destroy();
      }
    }

    // Update movement of beanie blobs
    for (var i = 0; i < this.beanieBlobs.getChildren().length; i++) {
      var beanieBlob = this.beanieBlobs.getChildren()[i];

      if (beanieBlob.x > this.scene.player.x) {

        beanieBlob.y = Phaser.Math.Interpolation.Linear(
          [beanieBlob.y, this.scene.player.y],
          0.01
        );

      }
      else {
        beanieBlob.x = Phaser.Math.Interpolation.Linear(
          [beanieBlob.x, -32],
          0.01
        );
      }
    }

    for (var i = 0; i < this.bubbles.getChildren().length; i++) {
      var bubble = this.bubbles.getChildren()[i];

      if (bubble.itemShown !== undefined) {
        bubble.itemShown.x = bubble.x;
        bubble.itemShown.y = bubble.y;
      }

      if (bubble.x < -64) {
        if (bubble.itemShown) {
          bubble.itemShown.destroy();
        }
        bubble.destroy();
      }
    }
  }
}

class Player extends Entity {
  constructor(scene, x, y) {
    super(scene, x, y, "sprPlayer");

    this.body.setSize(this.displayWidth, this.displayHeight);
    
    this.body.setAllowGravity(false);
    this.body.setSize(this.width - 6, this.height - 10);
    this.body.setOffset(3, 6);

    this.setData("isDead", false);
  }

  setDead() { // Used for "killing" the player throughout the code
    if (!this.getData("isDead")) {
      this.setData("isDead", true);

      this.scene.sfx.crash[Phaser.Math.Between(0, this.scene.sfx.crash.length - 1)].play();

      this.setTexture("sprPlayerCrashed");
      this.play("playerCrashedFly");

      this.body.velocity.x = 0;

      var particlesPlayerCrashed = this.scene.add.particles('sprParticlePlayerCrashed');
      var emitterPlayerCrashed = particlesPlayerCrashed.createEmitter({
        speed: { min: 300, max: 500 },
        lifespan: 1000,
        scale: { start: 0.5, end: 0 },
        gravityY: this.scene.game.config.physics.arcade.gravity.y,
        active: false
      });
      emitterPlayerCrashed.active = true;
      emitterPlayerCrashed.explode(10, this.x, this.y);

      // Create a timer that restarts the game
      this.scene.restartGame();
    }
  }

  hop() { // Used for applying velocity and spawning particles from the player
    this.body.velocity.y -= 300;

    this.setScale(this.scaleX - 0.01, this.scaleY - 0.01);

    var alpha = this.scaleX * 0.4;

    if (alpha < 0) { alpha = 0; }
    else if (alpha > 1) { alpha = 1; }

    this.setAlpha(alpha);

    if (this.scaleX < 0.75) {
      var particlesPlayerCrashed = this.scene.add.particles('sprParticlePlayerCrashed');
      var emitterPlayerCrashed = particlesPlayerCrashed.createEmitter({
        speed: { min: 300, max: 500 },
        lifespan: 1000,
        scale: { start: 0.5, end: 0 },
        gravityY: this.scene.game.config.physics.arcade.gravity.y,
        active: false
      });
      emitterPlayerCrashed.active = true;
      emitterPlayerCrashed.explode(10, this.x, this.y);

      this.setDead();
    }
  }

  grow() { // Used for growing the player
    this.setScale(this.scaleX + 0.1, this.scaleY + 0.1);

    var alpha = this.scaleX * 0.4;

    if (alpha < 0) { alpha = 0; }
    else if (alpha > 1) { alpha = 1; }

    this.setAlpha(alpha);
  }

  update() {
    if (this.y < 0) {
      this.y = 0;
      this.body.velocity.y = 0;
    }

    if (this.y > this.scene.game.config.height + 32) {
      this.setData("isDead", true);
    }

    if (this.getData("isDead")) {
      this.angle += Math.PI * this.body.velocity.y / 180;

      // Keep the position of the player particle emitter focused on the player
      if (this.emitterPlayerCrashed) {
        this.emitterPlayerCrashed.setPosition(this.x, this.y);
      }
    }
  }
}

class ItemTemplate {
  constructor(icon, callback) {
    this.icon = icon;
    this.callback = callback;
  }
}

class Bubble extends Entity {
  constructor(scene, x, y, itemTemplate) {
    super(scene, x, y, "sprBubble");
    this.itemTemplate = itemTemplate;

    this.setAlpha(0.8);

    // Add a sprite displaying the item that the bubble should contain
    this.itemShown = this.scene.add.sprite(x, y, itemTemplate.icon);
    this.itemShown.setDepth(this.depth + 1);
    this.itemShown.setAlpha(0.75);
    
    this.body.setAllowGravity(false);

    this.play("sprBubble");
  }
}

class ItemDrop extends Entity {
  constructor(scene, x, y, itemTemplate) {
    super(scene, x, y, itemTemplate.icon);
    this.itemTemplate = itemTemplate;
    this.setScale(0.75);
  }
}

class PillarBlob extends Entity {
  constructor(scene, x, y, pillar) {
    super(scene, x, y, "sprPillarBlob");
    this.play("sprPillarBlob");
    this.body.setAllowGravity(false);
    this.body.setImmovable(true);

    this.setDepth(pillar.depth - 3);

    this.setData("initialY", y);
    this.setData("state", "HUNKER");
    this.setData("pillar", pillar);

    // Add a sprite to show the eyes on the pillar blob
    this.eyes = this.scene.add.sprite(this.x, this.y, "sprPillarBlobEyes");
    this.eyes.y -= this.eyes.displayHeight * 0.5;
    this.eyes.setDepth(this.depth + 1);
    this.eyes.setScale(this.scene.spriteScale);
  }

  update() {
    this.x = this.getData("pillar").x;

    this.eyes.x = this.x;
    this.eyes.y = this.y - (this.displayHeight * 0.25);


    if (this.getData("state") == "HUNKER") {

      if (Phaser.Math.Distance.Between(
        this.scene.player.x,
        this.scene.player.y,
        this.x,
        this.y
      ) < 128) {

        this.body.setAllowGravity(true);
        this.body.setImmovable(false);

        this.body.velocity.y = -800;

        this.setData("state", "JUMP");
      }
    }
    else if (this.getData("state") == "JUMP") {
      if (this.y > this.getData("initialY") - 128) {
    this.displayHeight = Math.abs(this.body.velocity.y * 0.05);

      }
      else {
        this.setData("state", "FALL");
      }
    }
    else if (this.getData("state") == "FALL") {
      //this.body.velocity.y = 100;
    }
  }
}

class BalloonBlob extends Entity {
  constructor(scene, x, y) {
    super(scene, x, y, "sprBalloonBlob");
    this.play("sprBalloonBlob");

    this.body.setAllowGravity(false);
    this.body.setImmovable(true);
    this.body.setSize(this.width, 36, false);
  }
}

class BeanieBlob extends Entity {
  constructor(scene, x, y) {
    super(scene, x, y, "sprBeanieBlob");
    this.play("sprBeanieBlob");

    this.body.setAllowGravity(false);

    // Resize and offset the bounding box
    this.body.setSize(this.width - 4, this.height - 4);
    this.body.setOffset(2, 4);
  }
}

class RocketBlob extends Entity {
  constructor(scene, x, y) {
    super(scene, x, y, "sprRocketBlob"); 
    this.play("sprRocketBlob");

    this.body.setAllowGravity(false);
    this.body.setImmovable(true);

    this.states = {
      IDLE: "IDLE",
      FLYING: "FLYING"
    };
    this.state = this.states.IDLE;

    this.warning = this.scene.add.sprite(
      this.scene.game.config.width - 34,
      this.y,
      "sprWarning"
    );
    this.warning.setScale(this.scene.spriteScale);
    this.warning.setDepth(15);
    this.warning.play("sprWarningSlower");

    this.alarmEvent = this.scene.time.addEvent({
      delay: 400,
      callback: function() {
        this.scene.sfx.alarm.play();
      },
      callbackScope: this,
      loop: true
    });

    this.scene.time.addEvent({
      delay: 2000,
      callback: function() {
        this.warning.play("sprWarningFaster");

        if (this.alarmEvent) {
          this.alarmEvent.delay = 50;
        }
      },
      callbackScope: this,
      loop: false
    });

    this.scene.time.addEvent({
      delay: 3000,
      callback: function() {

        if (this.state == this.states.IDLE) {

          if (this.alarmEvent) {
            this.alarmEvent.destroy();
          }

          this.changeState(this.states.FLYING);

          this.scene.sfx.rocketFired[Phaser.Math.Between(0, this.scene.sfx.rocketFired.length - 1)].play();
        }

      },
      callbackScope: this,
      loop: false
    });
  }

  changeState(state) {
    this.state = state;

    switch (this.state) {
      case "FLYING": {
        if (this.warning) {
          this.warning.destroy();
        }

        this.body.velocity.x = -500;
        break;
      }
    }
  }
}

class BackgroundLayer extends Phaser.GameObjects.Sprite {
  constructor(scene, x, y, key, positionIndex, depth) {
    super(scene, x, y, key);
    this.scene.add.existing(this);
    this.scene.physics.world.enableBody(this, 0);

    this.setScale(this.scene.spriteScale);

    this.body.setAllowGravity(false);
    this.body.setImmovable(true);

    this.setData("positionIndex", positionIndex);
    this.setData("depth", depth);
  }
}

class Background {
  constructor(scene) {
    this.scene = scene;
    this.layers = []; // An array to store our instances of our BackgroundLayer class

    this.createBackgroundLayers();

    this.createForegroundLayers();
  }

  createBackgroundLayers() {

    // Creates two background layers next to each other
    for (var i = 0; i < 2; i++) {
      for (var j = 0; j < 3; j++) {
        var layer = new BackgroundLayer(this.scene, 0, 0, "sprBg" + j, i, j);
        layer.x = i * layer.displayWidth;
        layer.setDepth(-100 + (j))
        layer.setOrigin(0, 0);
        layer.body.velocity.x = -((j + 1) * 20);
        this.layers.push(layer);
      }
    }
  }

  createForegroundLayers() {

    // Creates two foreground layers next to each other
    for (var i = 0; i < 2; i++) {
      var depth = 5;

      var layer = new BackgroundLayer(this.scene, 0, 32, "sprFg0", i, depth);
      layer.x = i * layer.displayWidth;
      layer.setDepth(depth)
      layer.setOrigin(0, 0);
      layer.setBlendMode(Phaser.BlendModes.LIGHTEN);
      layer.body.velocity.x = -((depth + 1) * 20);
      this.layers.push(layer);
    }
  }

  getLayersOfPositionIndex(positionIndex) {
    var arr = [];

    for (var i = 0; i < this.layers.length; i++) {
      if (this.layers[i].getData("positionIndex") == positionIndex) {
        arr.push(this.layers[i]);
      }
    }

    return arr;
  }

  getLayersOfDepth(depth) {
    var arr = [];

    for (var i = 0; i < this.layers.length; i++) {
      if (this.layers[i].getData("depth") == depth) {
        arr.push(this.layers[i]);
      }
    }
    
    return arr;
  }

  update() {

    // Reset the position of each layer of a depth if the right side of the left-most image reaches the left side of the screen
    for (var i = 0; i < this.getLayersOfPositionIndex(0).length; i++) {
      var layer = this.getLayersOfPositionIndex(0)[i];

      if (layer.x + layer.displayWidth < 0) {
        for (var j = 0; j < this.getLayersOfDepth(layer.getData("depth")).length; j++) {
          var resetLayer = this.getLayersOfDepth(layer.getData("depth"))[j];

          resetLayer.x = resetLayer.getData("positionIndex") * resetLayer.displayWidth;
        }
      }
    }

  }
}