class SceneMain extends Phaser.Scene {
  constructor() {
    super({ key: "SceneMain" });
  }

  preload() {
    let base = "content/";

    // Load button images and HUD images
    this.load.image("sprBtnPlay", base + "sprBtnPlay.png");
    this.load.image("sprGetReady", base + "sprGetReady.png");


    // Load background images
    for (var i = 0; i < 3; i++) {
      this.load.image("sprBg" + i, base + "sprBg" + i + ".png");
    }

    // Load foreground images
    this.load.image("sprFg0", base + "sprFg0.png");

    // Load clouds
    for (var i = 0; i < 2; i++) {
      this.load.image("sprCloudLarge" + i, base + "sprCloudLarge" + i + ".png");
    }


    // Load entity images
    this.load.image("sprPillarDown", base + "sprPillarDown.png");
    this.load.image("sprPillarUp", base + "sprPillarUp.png");

    this.load.spritesheet("sprPlayer", base + "sprPlayer.png", {
      frameWidth: 32,
      frameHeight: 32
    });

    this.load.spritesheet("sprPlayerCrashed", base + "sprPlayerCrashed.png", {
      frameWidth: 32,
      frameHeight: 32
    });

    this.load.spritesheet("sprPillarBlob", base + "sprPillarBlob.png", {
      frameWidth: 32,
      frameHeight: 32
    });

    this.load.spritesheet("sprPillarBlobEyes", base + "sprPillarBlobEyes.png", {
      frameWidth: 8,
      frameHeight: 6
    });

    this.load.spritesheet("sprBalloonBlob", base + "sprBalloonBlob.png", {
      frameWidth: 32,
      frameHeight: 96
    });

    this.load.spritesheet("sprBeanieBlob", base + "sprBeanieBlob.png", {
      frameWidth: 32,
      frameHeight: 32
    });

    this.load.spritesheet("sprRocketBlob", base + "sprRocketBlob.png", {
      frameWidth: 64,
      frameHeight: 32
    });

    this.load.spritesheet("sprBubble", base + "sprBubble.png", {
      frameWidth: 32,
      frameHeight: 32
    });

    this.load.spritesheet("sprWarning", base + "sprWarning.png", {
      frameWidth: 32,
      frameHeight: 32
    });

    // Load particle images
    this.load.image("sprParticlePlayer", base + "sprParticlePlayer.png");
    this.load.image("sprParticlePlayerCrashed", base + "sprParticlePlayerCrashed.png");
    for (var i = 0; i < 2; i++) {
      this.load.image("sprParticleBalloonBlob" + i, base + "sprParticleBalloonBlob" + i + ".png");
    }
    this.load.image("sprParticleBubblePop", base + "sprParticleBubblePop.png");


    // Load sound effects

    this.load.audio("sndAlarm", base + "sndAlarm.mp3");

    // Load bubble burst sound effects
    for (var i = 0; i < 3; i++) {
      this.load.audio("sndBubbleBurst" + i, base + "sndBubbleBurst" + i + ".mp3");
    }

    // Load crash sound effects
    for (var i = 0; i < 3; i++) {
      this.load.audio("sndCrash" + i, base + "sndCrash" + i + ".mp3");
    }

    // Load flap sound effects
    for (var i = 0; i < 2; i++) {
      this.load.audio("sndFlap" + i, base + "sndFlap" + i + ".mp3");
    }

    // Load rocket fired sound effects
    for (var i = 0; i < 3; i++) {
      this.load.audio("sndRocketFired" + i, base + "sndRocketFired" + i + ".mp3");
    }
    
  }

  create() {
    console.log("CREATE");

    // Register our animations with Phaser
    this.anims.create({
      key: "playerFly",
      frames: this.anims.generateFrameNumbers("sprPlayer"),
      frameRate: 15,
      repeat: -1
    });

    this.anims.create({
      key: "playerFlyTap",
      frames: this.anims.generateFrameNumbers("sprPlayer"),
      frameRate: 15,
      repeat: 0
    });

    this.anims.create({
      key: "playerCrashedFly",
      frames: this.anims.generateFrameNumbers("sprPlayerCrashed"),
      frameRate: 10,
      repeat: -1
    });

    this.anims.create({
      key: "sprPillarBlob",
      frames: this.anims.generateFrameNumbers("sprPillarBlob"),
      frameRate: 10,
      repeat: -1
    });

    this.anims.create({
      key: "sprBalloonBlob",
      frames: this.anims.generateFrameNumbers("sprBalloonBlob"),
      frameRate: 10,
      repeat: -1
    });

    this.anims.create({
      key: "sprBeanieBlob",
      frames: this.anims.generateFrameNumbers("sprBeanieBlob"),
      frameRate: 30,
      repeat: -1
    });

    this.anims.create({
      key: "sprRocketBlob",
      frames: this.anims.generateFrameNumbers("sprRocketBlob"),
      frameRate: 20,
      repeat: -1
    });

    this.anims.create({
      key: "sprBubble",
      frames: this.anims.generateFrameNumbers("sprBubble"),
      frameRate: 5,
      repeat: -1
    });

    this.anims.create({
      key: "sprWarningSlower",
      frames: this.anims.generateFrameNumbers("sprWarning"),
      frameRate: 15,
      repeat: -1
    });

    this.anims.create({
      key: "sprWarningFaster",
      frames: this.anims.generateFrameNumbers("sprWarning"),
      frameRate: 30,
      repeat: -1
    });

    // Define our sound effects
    // We can organize them and group them together with an object
    this.sfx = {
      alarm: this.sound.add("sndAlarm"),
      bubbleBurst: [
        this.sound.add("sndBubbleBurst0"),
        this.sound.add("sndBubbleBurst1"),
        this.sound.add("sndBubbleBurst2")
      ],
      crash: [
        this.sound.add("sndCrash0"),
        this.sound.add("sndCrash1"),
        this.sound.add("sndCrash2")
      ],
      flap: [
        this.sound.add("sndFlap0"),
        this.sound.add("sndFlap1"),
      ],
      rocketFired: [
        this.sound.add("sndRocketFired0"),
        this.sound.add("sndRocketFired1"),
        this.sound.add("sndRocketFired2")
      ]
    };

    // Set the scale of sprites
    this.spriteScale = 2;

    // Used to determine whether or not the player has started the game
    this.hasReceivedStartTap = false;

    // Add an instance of the Background class, which represents our background (and included layers)
    this.background = new Background(this);

    // Instantiate a HighscoreManager (which helps us with reading and writing our high score when needed)
    this.highscoreManager = new HighscoreManager();

    // Instantiate an instance of the World class, used for managing game objects
    this.world = new World(this);

    // Instantiate the player
    this.player = new Player(this, this.game.config.width * 0.5, this.game.config.height * 0.5);
    this.player.play("playerFly");

    // Create the initial up and down flight pattern for the player
    this.tweenPlayer = this.tweens.add({
      targets: this.player,
      y: this.game.config.height * 0.6,
      ease: 'Sine.easeInOut',
      duration: 1000,
      yoyo: true,
      repeat: -1
    });

    // Create a particle emitter for the player, which emits when the player hops
    this.particlesPlayer = this.add.particles('sprParticlePlayer');
    this.emitterPlayer = this.particlesPlayer.createEmitter({
      speed: { min: 200, max: 300 },
      lifespan: 1000,
      scale: { start: 0.5, end: 0 },
      angle: { min: 80, max: 110 },
      gravityY: this.game.config.physics.arcade.gravity.y,
      active: false
    });

    // Create the "Get Ready" heading before the game starts
    this.getReady = this.add.sprite(this.game.config.width * 0.5, this.game.config.height * 0.2, "sprGetReady");
    this.getReady.setScale(2);
    this.getReady.setDepth(100);

    // Show the high score before the game starts
    this.textHighscore = new TextLongShadow(
      this,
      this.game.config.width * 0.5,
      this.getReady.y + 48,
      "HIGH: " + this.highscoreManager.read(),
      3,
      {
        color: "#ffffff",
        fontFamily: "font1",
        fontSize: 24,
      }
    );
    this.textHighscore.setOriginWithLongShadow(0.5);
    this.textHighscore.setDepthWithLongShadow(20);

    // Create a text object to show the score
    this.score = 0;
    this.textScore = new TextLongShadow(
      this,
      this.game.config.width * 0.5,
      64,
      this.score,
      3,
      {
        color: "#ffffff",
        fontFamily: "font1",
        fontSize: 48,
      }
    );
    this.textScore.setOriginWithLongShadow(0.5);
    this.textScore.setDepthWithLongShadow(20);
    this.textScore.setVisibleWithLongShadow(false);

    // Create the play (start) button
    this.btnStart = new MenuButton(
      this,
      this.game.config.width * 0.5,
      this.game.config.height * 0.8,
      function() {
        this.startGame();

        this.playerHop();
      }.bind(this)
    );

    // Define the colliders
    // The reason why we add them here is 
    this.physics.add.collider(this.player, this.world.pillars, function(player, pillar) {
      player.setDead();
    });

    this.physics.add.collider(this.player, this.world.pillarBlobs, function(player, pillarBlob) {
      player.setDead();
    });

    this.physics.add.overlap(this.player, this.world.balloonBlobs, function(player, balloonBlob) {

      var particlesPlayerCrashed = this.add.particles('sprParticleBalloonBlob0');
      var emitterPlayerCrashed = particlesPlayerCrashed.createEmitter({
        speed: { min: 300, max: 500 },
        lifespan: 1000,
        scale: { start: 1, end: 0 },
        gravityY: this.game.config.physics.arcade.gravity.y,
        active: false
      });
      emitterPlayerCrashed.active = true;
      emitterPlayerCrashed.explode(10, balloonBlob.x, balloonBlob.y);

      balloonBlob.destroy();

      player.setDead();
    }, null, this);

    this.physics.add.collider(this.player, this.world.beanieBlobs, function(player, balloonBlob) {
      player.setDead();
    });

    this.physics.add.overlap(this.player, this.world.bubbles, function(player, bubble) {

      this.sfx.bubbleBurst[Phaser.Math.Between(0, this.sfx.bubbleBurst.length - 1)].play();

      this.world.spawnItemDrop(bubble.x, bubble.y, bubble.itemTemplate);

      if (bubble.itemShown) {
        bubble.itemShown.destroy();
      }

      var particlesBubble = this.add.particles('sprParticleBubblePop');
      var bubbleEmitter = particlesBubble.createEmitter({
        speed: { min: 200, max: 300 },
        lifespan: 1000,
        angle: { min: 0, max: 360 },
        alpha: { start: 1, end: 0 },
        scale: { start: 0.5, end: 0 },
        gravityY: this.game.config.physics.arcade.gravity.y,
        active: false
      });
      bubbleEmitter.active = true;
      bubbleEmitter.explode(10, bubble.x, bubble.y);

      bubble.destroy();
    }, null, this);

    this.physics.add.overlap(this.player, this.world.rocketBlobs, function(player, rocketBlob) {
      player.setDead();
    }, null, this);

    this.physics.add.overlap(this.player, this.world.itemDrops, function(player, itemDrop) {

      if (itemDrop) {
        itemDrop.itemTemplate.callback(this.world, player);

        itemDrop.destroy();
      }

    }, null, this);

    this.physics.add.overlap(this.world.balloonBlobs, this.world.pillars, function(balloonBlob, pillar) {

      // If the balloon blob is off-screen still and it collides with a spawned pillar,
      // just remove it without particles.  However, if the balloon blob collides
      // with a spawned pillar and it happens on-screen, remove the balloon blob
      // and spawn a bunch of balloon blob particles.
      if (balloonBlob.x > this.game.config.width) {
        balloonBlob.destroy();
      }
      else {
        this.sfx.bubbleBurst[Phaser.Math.Between(0, this.sfx.bubbleBurst.length - 1)].play();

        var particlesPlayerCrashed = this.add.particles('sprParticleBalloonBlob0');
        var emitterPlayerCrashed = particlesPlayerCrashed.createEmitter({
          speed: { min: 300, max: 500 },
          lifespan: 1000,
          scale: { start: 1, end: 0 },
          gravityY: this.game.config.physics.arcade.gravity.y,
          active: false
        });
        emitterPlayerCrashed.active = true;
        emitterPlayerCrashed.explode(10, balloonBlob.x, balloonBlob.y);
  
        balloonBlob.destroy();
      }
    }, null, this);

    this.physics.add.overlap(this.world.bubbles, this.world.pillars, function(bubble, pillar) {
      bubble.destroy();
    });

    this.input.keyboard.on("keydown_SPACE", function(e) {
      this.startGame();

      this.playerHop();
    }, this);

    this.input.on("pointerdown", function() {
      this.playerHop();
    }, this);
  }

  addToScore(amount) {
    this.score += amount;
    this.textScore.setTextWithLongShadow(this.score);
  }

  startGame() {
    if (!this.hasReceivedStartTap) {
      this.getReady.setVisible(false);

      this.textHighscore.setVisibleWithLongShadow(false);

      this.textScore.setVisibleWithLongShadow(true);

      this.player.body.setAllowGravity(true);

      this.tweenPlayer.remove();

      this.world.startSpawnTimers();

      this.btnStart.destroy();

      this.hasReceivedStartTap = true;
    }
  }

  restartGame() {
    this.time.addEvent({
      delay: 3000,
      callback: function() {
        this.highscoreManager.saveIfNeeded(this.score);
        this.scene.start("SceneMain");
      },
      callbackScope: this,
      loop: false
    });
  }

  playerHop() {

    if (this.hasReceivedStartTap) {
      if (!this.player.getData("isDead")) {
        this.player.hop();

        this.sfx.flap[Phaser.Math.Between(0, this.sfx.flap.length - 1)].play();

        this.player.play("playerFlyTap");
        this.emitterPlayer.active = true;
        this.emitterPlayer.explode(3, this.player.x, this.player.y);
      }
    }
  }

  update() {
    this.background.update();

    if (this.hasReceivedStartTap) {
      this.world.update(); // Update frustum culling and some enemy movement logic within the instance of World
    }

    this.player.update();

    if (this.player.y > this.game.config.height) {
      this.player.setDead();
    }

    this.emitterPlayer.setPosition(this.player.x, this.player.y);
  }
}
